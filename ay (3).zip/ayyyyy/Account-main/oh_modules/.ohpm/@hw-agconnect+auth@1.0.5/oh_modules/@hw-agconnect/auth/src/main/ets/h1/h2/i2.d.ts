/**
 * 参考Java实现，根据三段组件获取password
 * @param xBytes 组件x
 * @param yBytes 组件y
 * @param zBytes 组件x
 */
export declare function getKey(xBytes: any, yBytes: any, zBytes: any): any;
