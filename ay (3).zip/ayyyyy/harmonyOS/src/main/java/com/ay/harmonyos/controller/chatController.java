package com.ay.harmonyos.controller;


import com.ay.harmonyos.entity.Message;
import com.ay.harmonyos.service.MessageService;
import com.ay.harmonyos.utils.LoadHistoryToMemory;
import jakarta.annotation.Resource;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor;
import org.springframework.ai.chat.client.advisor.SimpleLoggerAdvisor;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.openai.OpenAiChatOptions;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

@RestController
@RequestMapping("/api/ai")
public class chatController {
    @Resource
    public ChatClient chatClient;

    @Resource
    private MessageService messageService;

    @Resource
    private LoadHistoryToMemory loadHistoryToMemory;

    @Resource
    private ChatMemory chatMemory;

    /**
     * 非流式调用，直接返回一个字符串
     * @param prompt 用户输入的提示词
     * @return AI回复内容
     */
    @RequestMapping("/chat/call")
    public String chatCall(String prompt){
        try {
            return chatClient.prompt(prompt).call().content();
        } catch (Exception e){
            return "抱歉，服务暂时不可用，请稍后再试。";
        }
    }

    /**
     * 流式调用，支持会话历史和模型切换
     * @param prompt 用户输入的提示词
     * @param chatId 会话ID（必填，必须由前端传入）
     * @param userId 用户ID（必填，必须由前端传入）
     * @return 流式响应
     */
    @RequestMapping(value = "/chat/stream", produces = "text/html;charset=utf-8")
    public Flux<String> chatStream(@RequestParam String prompt,
                                   @RequestParam String chatId,
                                   @RequestParam Long userId){
        try {
            final String finalChatId = chatId;
            final Long finalUserId = userId;

            // 先加载历史消息到ChatMemory中（在保存当前消息之前）
            // 使用新方法加载历史消息，支持0（用户消息）和1（AI消息）的格式
            loadHistoryToMemory.loadHistoryToMemory(finalChatId);

            // 保存用户消息
            messageService.saveUserMessage(finalChatId, prompt, finalUserId);

            // 将当前用户消息添加到ChatMemory中
            chatMemory.add(finalChatId, new UserMessage(prompt));

            Flux<String> responseFlux = chatClient
                    .prompt()
                    .user(prompt)
                    .options(OpenAiChatOptions.builder().model("qwen-max").build())
                    .advisors(a -> a.param(MessageChatMemoryAdvisor.CHAT_MEMORY_CONVERSATION_ID_KEY, finalChatId))
                    .stream()
                    .content();

            // 收集完整响应并保存AI消息
            StringBuilder completeResponse = new StringBuilder();

            return responseFlux.doOnNext(response -> {
                // 将响应内容保存到completeResponse中
                completeResponse.append(response);
            }).doOnComplete(() -> {
                // 流式响应完成后，保存完整的AI回复到数据库
                if (completeResponse.length() > 0) {
                    messageService.saveAiMessage(finalChatId, completeResponse.toString(), finalUserId);
                }
            }).doOnCancel(() -> {
                // 处理流式响应被取消的情况
                if (completeResponse.length() > 0) {
                    messageService.saveAiMessage(finalChatId, completeResponse.toString(), finalUserId);
                }
            });
        } catch (Exception e) {
            return Flux.just("抱歉，服务暂时不可用，请稍后再试。");
        }
    }
}