package com.ay.harmonyos.service.impl;


import com.ay.harmonyos.entity.Message;
import com.ay.harmonyos.mapper.MessageMapper;
import com.ay.harmonyos.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class MessageServiceImpl implements MessageService {

    @Autowired
    private MessageMapper messageMapper;

    @Override
    public List<Message> getMessagesByChatId(String chatId) {
        return messageMapper.getMessagesByChatId(chatId);
    }

    @Override
    public void saveUserMessage(String chatId, String content, Long userId) {
        Message message = new Message();
        message.setChatId(chatId);
        message.setContent(content);
        message.setIsAiMessage(0);
        message.setUserId(userId);
        message.setCreateTime(new Date());
        messageMapper.insertMessage(message);
    }

    @Override
    public void saveAiMessage(String chatId, String content, Long userId) {
        Message message = new Message();
        message.setChatId(chatId);
        message.setContent(content);
        message.setIsAiMessage(1);
        message.setUserId(userId);
        message.setCreateTime(new Date());
        messageMapper.insertMessage(message);
    }
}