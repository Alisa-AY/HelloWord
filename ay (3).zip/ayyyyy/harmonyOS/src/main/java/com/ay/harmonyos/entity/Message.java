package com.ay.harmonyos.entity;

import java.io.Serializable;
import java.util.Date;

public class Message implements Serializable {
    private Long id;

    private String chatId;

    private String content;

    private Integer isAiMessage;

    private Long userId;

    private Date createTime;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getChatId() {
        return chatId;
    }

    public void setChatId(String chatId) {
        this.chatId = chatId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getIsAiMessage() {
        return isAiMessage;
    }

    public void setIsAiMessage(Integer isAiMessage) {
        this.isAiMessage = isAiMessage;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}