package com.ay.harmonyos;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.ay.harmonyos.mapper")
public class HarmonyOsApplication {

    public static void main(String[] args) {
        SpringApplication.run(HarmonyOsApplication.class, args);
    }

}
