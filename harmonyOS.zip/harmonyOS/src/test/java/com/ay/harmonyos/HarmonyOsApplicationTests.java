package com.ay.harmonyos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HarmonyOsApplicationTests {

    @Test
    void contextLoads() {
    }

}
