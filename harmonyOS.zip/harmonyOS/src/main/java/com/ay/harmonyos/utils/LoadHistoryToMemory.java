package com.ay.harmonyos.utils;


import com.ay.harmonyos.entity.Message;
import com.ay.harmonyos.service.MessageService;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 历史消息加载工具类
 */
@Component
public class LoadHistoryToMemory {

    @Autowired
    private ChatMemory chatMemory;

    @Autowired
    private MessageService messageService;

    /**
     * 将历史消息加载到ChatMemory中（适用于Spring AI）
     * @param chatId 聊天会话ID
     */
    public void loadHistoryToMemory(String chatId) {
        try {
            // 获取历史消息
            List<Message> historyMessages = messageService.getMessagesByChatId(chatId);

            if (historyMessages != null && !historyMessages.isEmpty()) {
                // 清除该会话的旧记忆
                chatMemory.clear(chatId);

                // 将历史消息添加到ChatMemory中
                for (Message message : historyMessages) {
                    if (message.getIsAiMessage() == 0) {
                        // 用户消息 (0代表用户消息)
                        chatMemory.add(chatId, new UserMessage(message.getContent()));
                    } else {
                        // AI消息 (1代表AI消息)
                        chatMemory.add(chatId, new AssistantMessage(message.getContent()));
                    }
                }
            }
        } catch (Exception e) {
            // 记录错误但不影响主流程
            System.err.println("加载历史消息到ChatMemory失败: " + e.getMessage());
        }
    }

    /**
     * 按类型加载历史消息到内存中
     * @param chatId 聊天会话ID
     * @return 包含消息类型和内容的二维数组，其中0代表用户消息，1代表AI消息
     */
    public Object[][] loadHistoryAsArray(String chatId) {
        try {
            // 获取历史消息
            List<Message> historyMessages = messageService.getMessagesByChatId(chatId);

            if (historyMessages != null && !historyMessages.isEmpty()) {
                Object[][] historyArray = new Object[historyMessages.size()][2];
                for (int i = 0; i < historyMessages.size(); i++) {
                    Message message = historyMessages.get(i);
                    // 0代表用户消息，1代表AI消息
                    historyArray[i][0] = message.getIsAiMessage() == 0 ? 0 : 1;
                    historyArray[i][1] = message.getContent();
                }
                return historyArray;
            }
            return new Object[0][0]; // 返回空数组
        } catch (Exception e) {
            System.err.println("加载历史消息为数组失败: " + e.getMessage());
            return new Object[0][0]; // 返回空数组
        }
    }

    /**
     * 从数组格式加载历史消息到ChatMemory
     * @param chatId 聊天会话ID
     * @param historyArray 包含消息类型和内容的二维数组
     */
    public void loadHistoryFromArrray(String chatId, Object[][] historyArray) {
        try {
            // 清除现有记忆
            chatMemory.clear(chatId);
            
            if (historyArray != null && historyArray.length > 0) {
                for (Object[] messageData : historyArray) {
                    int messageType = (int) messageData[0]; // 0为用户消息，1为AI消息
                    String content = (String) messageData[1];
                    
                    if (messageType == 0) {
                        // 用户消息
                        chatMemory.add(chatId, new UserMessage(content));
                    } else if (messageType == 1) {
                        // AI消息
                        chatMemory.add(chatId, new AssistantMessage(content));
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("从数组加载历史消息到ChatMemory失败: " + e.getMessage());
        }
    }
}