package com.ay.harmonyos.mapper;

import com.ay.harmonyos.entity.Message;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface MessageMapper {
    List<Message> getMessagesByChatId(@Param("chatId") String chatId);
    void insertMessage(Message message);
}