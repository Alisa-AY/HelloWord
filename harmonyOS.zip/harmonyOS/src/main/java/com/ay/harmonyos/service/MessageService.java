package com.ay.harmonyos.service;

import com.ay.harmonyos.entity.Message;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface MessageService {
    List<Message> getMessagesByChatId(String chatId);
    void saveUserMessage(String chatId, String content, Long userId);
    void saveAiMessage(String chatId, String content, Long userId);
}