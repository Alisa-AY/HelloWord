package com.ay.harmonyos.config;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor;
import org.springframework.ai.chat.client.advisor.SimpleLoggerAdvisor;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.chat.memory.InMemoryChatMemory;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.ai.openai.OpenAiChatOptions;
import org.springframework.ai.openai.api.OpenAiApi;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Spring AI配置类
 */
@Configuration
public class SpringAiConfig {

    @Value("${spring.ai.openai.api-key:sk-9ed0efb26d56441d874ef1ff78ce7c5e}")
    private String apiKey;

    @Value("${spring.ai.openai.base-url:https://dashscope.aliyuncs.com/compatible-mode}")
    private String baseUrl;

    @Value("${spring.ai.openai.chat.options.model:qwen-max}")
    private String model;

    /**
     * 创建OpenAI API客户端
     * @return OpenAiApi实例
     */
    @Bean
    public OpenAiApi openAiApi() {
        return new OpenAiApi(baseUrl, apiKey);
    }

    /**
     * 创建OpenAI聊天模型
     * @param openAiApi OpenAI API客户端
     * @return OpenAiChatModel实例
     */
    @Bean
    public OpenAiChatModel openAiChatModel(OpenAiApi openAiApi) {
        OpenAiChatOptions options = OpenAiChatOptions.builder()
                .model(model)
                .build();
        return new OpenAiChatModel(openAiApi, options);
    }

    /**
     * 创建一个默认的ChatMemory，用于存储对话历史记录
     * @return ChatMemory实例
     */
    @Bean
    public ChatMemory chatMemory() {
        return new InMemoryChatMemory();
    }

    /**
     * 对话机器人的ChatClient
     * @param model OpenAI聊天模型
     * @param chatMemory 聊天记忆
     * @return ChatClient实例
     */
    @Bean
    public ChatClient chatClient(OpenAiChatModel model, ChatMemory chatMemory) {
        return ChatClient.builder(model) // 创建ChatClient工厂
                .defaultSystem("你是小猫小说的小助手，请友好、准确地回答用户的问题")
                .defaultAdvisors(new SimpleLoggerAdvisor()) // 添加一个日志拦截器
                .defaultAdvisors(new MessageChatMemoryAdvisor(chatMemory)) // 添加一个会话历史记录的拦截器,用于会话记忆
                .build(); // 构建ChatClient实例
    }
}